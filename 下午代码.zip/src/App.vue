<template>
  <div class="app">
    <!-- 路由出口 -->
    <router-view></router-view>
  </div>
</template>

<script>
export default {};
</script>

<style lang="less">
// 使用less    lang="less"
@import url(~@/style/base.css);
</style>